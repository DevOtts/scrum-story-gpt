chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed");

  // You can perform other actions here that are compatible with Manifest V3
  // For example, setting up default settings, initializing something, etc.
});
